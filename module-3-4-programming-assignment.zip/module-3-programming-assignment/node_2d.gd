extends Node2D
signal picked_up
var score = 0
var lives = 3
@onready var score_label: Label = $Camera2D/HUD/Score
@onready var spawn_point: Marker2D = $SpawnPoint
@onready var telep_1: Marker2D = $Telep1 

func _ready():
	$Player.reset(spawn_point.position)

func _on_coins_tree_entered() -> void:
	picked_up.emit()
	queue_free()


func _on_coin_body_entered(body: Node2D) -> void:
	picked_up.emit()
	$coin.hide()
	_on_hud_score_change()
	
func _on_coin_2_body_entered(body: Node2D) -> void:
	picked_up.emit()
	$coin2.hide()
	_on_hud_score_change()
	
func _on_coin_3_body_entered(body: Node2D) -> void:
	picked_up.emit()
	$coin3.hide()
	_on_hud_score_change()
	
func _on_coin_4_body_entered(body: Node2D) -> void:
	picked_up.emit()
	$coin4.hide()
	_on_hud_score_change()
	

func _on_hud_score_change() -> void:
	score = score + 1
	$Player/Camera2D/HUD/Score.text = str(score)


func _on_danger_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		lives -= 1
		$Player/Camera2D/HUD/Lives.text = str(lives)
	if lives == 2:
		$Player/Camera2D/HUD/LifeCounter/Life.hide()
	if lives == 1:
		$Player/Camera2D/HUD/LifeCounter/Life2.hide()
	if lives == 0:
		get_tree().change_scene_to_file("res://end_bad.tscn")


func _on_enemy_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		$enemy/Goomba.queue_free()
		_on_danger_body_entered(body)


func _on_coin_5_body_entered(body: Node2D) -> void:
	picked_up.emit()
	$coin5.hide()
	_on_hud_score_change()
	
func _on_coin_6_body_entered(body: Node2D) -> void:
	picked_up.emit()
	$coin6.hide()
	_on_hud_score_change()
