extends Area2D
signal picked_up
var textures = {
	"coin": "res://coin 16.png"
}
func init(type, _position):
	$Coin.texture = load(textures[type])
	position = _position
	
func _on_body_entered(body):
	picked_up.emit()
	queue_free()
