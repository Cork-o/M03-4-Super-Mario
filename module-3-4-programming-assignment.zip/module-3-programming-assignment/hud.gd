extends Control
signal score_change
@onready var score_label: Label = $Score
@onready var life_counter = $LifeCounter.get_children()


func update_life(value):
	for heart in life_counter.size():
		life_counter[heart].visible = value > heart

func _on_score_change() -> void:
	var score = 0
	score = score + 1
	$HUD/Score.text = str(score)
